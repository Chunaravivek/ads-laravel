<?php

namespace App\Http\Middleware;

use Closure;

class AddConstantsFilesToAllRoutes
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
       
        require_once app_path() . '/constants.php'; 
        return $next($request);
    }
}
