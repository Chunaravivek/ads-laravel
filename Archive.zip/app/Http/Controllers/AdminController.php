<?php

namespace App\Http\Controllers;

use App\Admin;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Session;

class AdminController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct() {
        $this->middleware(function ($request, $next) {

            $currentAction = $request->route()->getActionName();
            list($controller, $method) = explode('@', $currentAction);
            $controller = preg_replace('/.*\\\/', '', $controller);
            $controller = str_replace('Controller', '', $controller);

            $name = $request->session()->get('full_name');
            $email = $request->session()->get('email');
            $id = $request->session()->get('admin_id');
            $status = $request->session()->get('status');

            view()->share([
                'controller' => strtolower($controller),
                'action' => $request->route()->getActionMethod(),
                'name' => $name,
                'email' => $email,
                'id' => $id,
                'status' => $status,
            ]);

            return $next($request);
        });
    }

    public function index() {
        return view('Admin.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        return view('Admin.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        if ($request->isMethod('post')) {
            $post_arr = [];

            $datas = array_map('trim', $request->all());

            unset($datas['_token']);

            $post_arr = $datas;
            $post_arr['created_date'] = time();
            $post_arr['modified_date'] = time();

            if (DB::table('admins')->insert($post_arr)) {
                $request->session()->flash('success', 'Admin has been Add successfully');
            } else {
                $request->session()->flash('dangers', "Unable to Add Admin");
            }
        }

        return redirect('/admin');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {

        if (DB::table('admins')->where('id', $id)->exists()) {
            return view('Admin.edit', ['datas' => DB::table('admins')->find($id),]);
        } else {
            $request->session()->flash('dangers', "Not Exists Admin Id.");
            return redirect('/admin');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request, Admin $admin) {

        if ($request->isMethod('post') || $request->isMethod('put')) {

            $post_arr = [];

            $datas = array_map('trim', $request->all());

            unset($datas['_token']);

            $post_arr = $datas;

            if (Admin::where('id', $id)->exists()) {

                $post_arr['modified_date'] = time();

                if (DB::table('admins')->where('id', $id)->update($post_arr)) {
                    $request->session()->flash('success', 'Admin has been update successfully');
                } else {
                    $request->session()->flash('dangers', "Unable to update Admin");
                }
            }
        }
        return redirect('/admin');
    }

    public function login(Request $request) {
        if ($request->session()->has('admin_id')) {
            return redirect('dashboard');
        }

        if ($request->isMethod('POST')) {

            $datas = $request->all();

            if (!isset($datas['_token']) && $datas['_token'] == '') {
                return redirect('/admin');
            } else {
                $email = $datas['email'];
                $pass = $datas['password'];
                $token = $datas['_token'];

                $admins = new Admin;

                $check = $admins->IfEmailandPassword($email, $pass);

                if (count($check) > 0) {

                    foreach ($check as $val) {
                        $request->session()->put('admin_id', $val->id);
                        $request->session()->put('full_name', $val->full_name);
                        $request->session()->put('email', $val->email);
                        $request->session()->put('status', $val->status);
                    }

                    return redirect('/dashboard');
                } else {
                    $request->session()->flash('dangers', 'Invalid email or Password');
                }
            }

            return redirect('/admin/login');
        }
        return view('Admin.login');
    }

    public function update_status(Request $request) {

        if ($request->isMethod('post') || $request->isMethod('put')) {
            $input = $request->all();

            $id = $input['id'];
            $status = $input['status_val'];

            if (Admin::where('id', $id)->exists()) {

                DB::table('admins')->where('id', $id)->update(array('status' => $status));
            }
        }
        unset($id);
        unset($status);
        exit;
    }

    public function logout(Request $request) {

        $request->session()->forget('admin_id');
        $request->session()->forget('email');
        $request->session()->forget('name');
        $request->session()->forget('status');

        return redirect('/admin');
    }

    public function records(Request $request) {

        if (isset($request->sidx) && $request->sidx != NULL) {
            $order_name = "admins." . $request->sidx;
            $order_sord = $request->sord;
        } else {
            $order_name = "admins.modified_date";
            $order_sord = "DESC";
        }

        $conditions = '1=1 ';

        if (isset($request->filters) && $request->filters != '') {
            $filters = json_decode($request->filters);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`admins." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`admins." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`admins." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`admins." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`admins." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`admins." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`admins." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`admins." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`admins." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`admins." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }

            $conditions = substr($conditions, 0, -4);
        }

        $i = 0;
        $result = array();

        if (isset($request->page) && $request->page != '') {
            $result['page'] = (int) $request->page;
        } else {
            $result['page'] = 1;
        }


        if (isset($request->rows) && $request->rows != '') {
            $limit = (int) $request->rows;
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;
        $keys = DB::table('admins')->whereRaw($conditions)->orderBy($order_name, $order_sord)->offset($offset)->limit($limit)->get();

        $counts = DB::table('admins')->whereRaw($conditions)->count();

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {
            $result['rows'][$i]['id'] = $key->id;
            $result['rows'][$i]['cell'] = array(
                '',
                $key->id,
                $key->full_name,
                $key->email,
                $key->password,
                date('d/m/Y', $key->created_date),
                date('d/m/Y h:i:s A', $key->modified_date),
                $key->status,
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function inline(Request $request) {

        $data = array();

        if (!empty($request->all()) && $request->oper == 'edit') {
            $data = $request->all();
            $data['modified_date'] = time();
            if (DB::table('admins')->where('id', $request->id)->update($data)) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($request->all()) && $request->oper == 'del') {
            $id_arr = explode(',', $request->id);

            foreach ($id_arr as $del_id) {

                DB::table('admins')->where('id', $del_id)->delete();
            }
            exit;
        }
    }

}
