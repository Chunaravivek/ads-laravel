<?php

namespace App;
use App\Admin;
use Illuminate\Database\Eloquent\Model;

class Admin extends Model {

    protected $table = 'admins';
    protected $primaryKey = 'id';
    public $incrementing = true;
    protected $fillable = [
        'full_name', 'email', 'password', 'status', 'created_date', 'modified_date'
    ];

    public function IfEmailandPassword($email, $pass) {
        
        return Admin::where(array('email'=> $email,'password' => $pass))->get();
        
    }
    
    public function Counts() {
        
        return Admin::count();
        
    }

}
