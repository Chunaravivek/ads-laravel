<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta charset="utf-8">
        <title>Login Admin</title>
        <meta name="description" content="User login page">
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <!-- bootstrap & fontawesome -->
        <script src="<?php echo BASE_URL ?>assets/js/jquery-2.1.4.min.js"></script>
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/font-awesome/4.5.0/css/font-awesome.min.css">
        <!-- text fonts -->
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/fonts.googleapis.com.css">
        <!-- ace styles -->
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/ace.min.css">
        <!--[if lte IE 9]>
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/ace-part2.min.css" />
        <![endif]-->
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/ace-rtl.min.css">
        <!--[if lte IE 9]>
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/ace-ie.min.css" />
        <![endif]-->
        <!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->
        <!--[if lte IE 8]>
        <script src="<?php echo BASE_URL ?>assets/js/html5shiv.min.js"></script>
        <script src="<?php echo BASE_URL ?>assets/js/respond.min.js"></script>
        <![endif]-->

        <!-- page specific plugin styles -->
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/jquery-ui.custom.min.css">
        <link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/jquery.gritter.min.css">

    </head>
    <body class="login-layout">
        <div class="main-container">
            <div class="main-content">
                <div class="row">
                    @yield('content')
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.main-content -->
        </div>
        <!-- /.main-container -->
        <!-- basic scripts -->
        <!--[if !IE]> -->
        <script src="<?php echo BASE_URL ?>assets/js/jquery-ui.custom.min.js"></script>
        <script src="<?php echo BASE_URL ?>assets/js/jquery.gritter.js"></script>
        <script src="<?php echo BASE_URL ?>assets/js/jquery.gritter.min.js"></script>
        <script async="" src="//www.google-analytics.com/analytics.js"></script>
        <script type="text/javascript" async="" src="http://mc.yandex.ru/metrika/watch.js"></script>


        <!-- <![endif]-->
        <!--[if IE]>
        <script src="<?php echo BASE_URL ?>assets/js/jquery-1.11.3.min.js"></script>
        <![endif]-->
        <script type="text/javascript">
            if ('ontouchstart' in document.documentElement)
                document.write("<script src='<?php echo BASE_URL ?>assets/js/jquery.mobile.custom.min.js'>" + "<" + "/script>");
        </script>
        <!-- inline scripts related to this page -->
        <script type="text/javascript">
            jQuery(function ($) {
                $(document).on('click', '.toolbar a[data-target]', function (e) {
                    e.preventDefault();
                    var target = $(this).data('target');
                    $('.widget-box.visible').removeClass('visible');//hide others
                    $(target).addClass('visible');//show target
                });
            });



            //you don't need this, just used for changing background
            jQuery(function ($) {
                $('#btn-login-dark').on('click', function (e) {
                    $('body').attr('class', 'login-layout');
                    $('#id-text2').attr('class', 'white');
                    $('#id-company-text').attr('class', 'blue');

                    e.preventDefault();
                });
                $('#btn-login-light').on('click', function (e) {
                    $('body').attr('class', 'login-layout light-login');
                    $('#id-text2').attr('class', 'grey');
                    $('#id-company-text').attr('class', 'blue');

                    e.preventDefault();
                });
                $('#btn-login-blur').on('click', function (e) {
                    $('body').attr('class', 'login-layout blur-login');
                    $('#id-text2').attr('class', 'white');
                    $('#id-company-text').attr('class', 'light-blue');

                    e.preventDefault();
                });

            });
        </script>
        <!-- Yandex.Metrika counter -->
        <script type="text/javascript">
            (function (d, w, c) {
                (w[c] = w[c] || []).push(function () {
                    try {
                        w.yaCounter25836836 = new Ya.Metrika({id: 25836836,
                            webvisor: true,
                            clickmap: true,
                            trackLinks: true,
                            accurateTrackBounce: true});
                    } catch (e) {
                    }
                });

                var n = d.getElementsByTagName("script")[0],
                        s = d.createElement("script"),
                        f = function () {
                            n.parentNode.insertBefore(s, n);
                        };
                s.type = "text/javascript";
                s.async = true;
                s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

                if (w.opera == "[object Opera]") {
                    d.addEventListener("DOMContentLoaded", f, false);
                } else {
                    f();
                }
            })(document, window, "yandex_metrika_callbacks");
        </script>
        <noscript>
        <div>
            <img src="//mc.yandex.ru/watch/25836836" alt="" />
        </div>
        </noscript>
        <!-- /Yandex.Metrika counter -->
        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-38894584-2', 'auto');
            ga('send', 'pageview');

        </script>

    </body>
</html>