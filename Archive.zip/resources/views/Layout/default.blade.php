@include('Elements.header')
@yield('content')
@include('Elements.footer')