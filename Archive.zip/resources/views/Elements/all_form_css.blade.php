<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/jquery-ui.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/jquery-ui.custom.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/jquery.gritter.min.css">
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/chosen.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/bootstrap-timepicker.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/daterangepicker.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/bootstrap-colorpicker.min.css" />
<link rel="stylesheet" href="<?php echo BASE_URL ?>assets/css/ui.jqgrid.min.css" />
