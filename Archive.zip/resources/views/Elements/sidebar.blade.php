<div id="sidebar" class="sidebar responsive ace-save-state" data-sidebar="true" data-sidebar-scroll="true" data-sidebar-hover="true">
    <script type="text/javascript">
        try {
            ace.settings.loadState('sidebar')
        } catch (e) {
        }
    </script>
    <ul class="nav nav-list">
        <li class="{{ request()->is('dashboard*') ? 'active' : '' }}">
            <a href="<?php echo BASE_URL;?>dashboard">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Dashboard </span>
            </a>

            <b class="arrow"></b>
        </li>

        <li class="{{ request()->is('admin*') ? 'active' : '' }}">
            <a href="<?php echo BASE_URL;?>admin">
                <i class="menu-icon fa fa-users"></i>
                <span class="menu-text"> Admin </span>
            </a>
            <b class="arrow"></b>
        </li>

        <li class="">

            <a href="<?php echo BASE_URL;?>admin/logout">
                <i class="menu-icon fa fa-sign-out"></i>
                <span class="menu-text"> Logout </span>
            </a>

            <b class="arrow"></b>
        </li>


    </ul><!-- /.nav-list -->

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>
</div>
