<script type="text/javascript" language="javascript" class="init">
    $(function () {
        $.extend($.gritter.options, {
            class_name: 'gritter-light', // for light notifications (can be added directly to $.gritter.add too)
            position: 'top-right', // possibilities: bottom-left, bottom-right, top-left, top-right
            fade_in_speed: 100, // how fast notifications fade in (string or int)
            fade_out_speed: 100, // how fast the notices fade out
            time: 3000 // hang on the screen for...
        });

    <?php if (Session::has('success')) { ?>
            $.gritter.add({
                title: "<?php echo Session::get('success'); ?>",
                class_name: 'gritter-success',

            });
    <?php } else if (Session::has('dangers')) { ?>
            $.gritter.add({
                title: "<?php echo Session::get('dangers'); ?>",
                class_name: 'gritter-error',

            });
    <?php } ?>
    });
</script>
