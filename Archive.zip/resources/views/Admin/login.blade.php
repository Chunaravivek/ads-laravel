@extends('Layout.user')

@section('content')

<div class="col-sm-10 col-sm-offset-1">
    <div class="login-container">
        <div class="center">
            <h1>
                <i class="ace-icon fa fa-leaf green"></i>
                <span class="red">Ads</span>
                <span class="white" id="id-text2">Application</span>
            </h1>
            <h4 class="blue" id="id-company-text">© S4 Company</h4>
            <h4>@include('Elements.message')</h4>
        </div>
        <div class="space-6"></div>
        <div class="position-relative">
            <div id="login-box" class="login-box visible widget-box no-border">
                <div class="widget-body">
                    <div class="widget-main">
                        <h4 class="header blue lighter bigger">
                            <i class="ace-icon fa fa-coffee green"></i>
                            Please Enter Your Information
                        </h4>
                        <div class="space-6"></div>
                        <form action="/admin" class="" method="POST" id="Adminaddform" enctype="multipart/form-data">
                            @csrf
                            <fieldset>
                                <label class="block clearfix">
                                    <span class="block input-icon input-icon-right">
                                        <input type="email" name="email" class="form-control" placeholder="Email" required="">
                                        <i class="ace-icon fa fa-user"></i>
                                    </span>
                                </label>
                                <label class="block clearfix">
                                    <span class="block input-icon input-icon-right">
                                        <input type="password" name="password" class="form-control" placeholder="Password" required="">
                                        <i class="ace-icon fa fa-lock"></i>
                                    </span>
                                </label>
                                <div class="space"></div>
                                <div class="clearfix">

                                    <button type="submit" class="width-35 pull-right btn btn-sm btn-primary">
                                        <i class="ace-icon fa fa-key"></i>
                                        <span class="bigger-110">Login</span>
                                    </button>
                                </div>
                                <div class="space-4"></div>
                            </fieldset>
                        </form>
                        <div class="space-6"></div>
                    </div>
                    <!-- /.widget-main -->
                </div>
                <!-- /.widget-body -->
            </div>
            <!-- /.login-box -->
        </div>
        <!-- /.position-relative -->
        <div class="navbar-fixed-top align-right">
            <br>
            &nbsp;
            <a id="btn-login-dark" href="#">Dark</a>
            &nbsp;
            <span class="blue">/</span>
            &nbsp;
            <a id="btn-login-blur" href="#">Blur</a>
            &nbsp;
            <span class="blue">/</span>
            &nbsp;
            <a id="btn-login-light" href="#">Light</a>
            &nbsp; &nbsp; &nbsp;
        </div>
    </div>
</div>

@endsection('content')