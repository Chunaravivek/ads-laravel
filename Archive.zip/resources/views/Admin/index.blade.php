@extends('Layout.default')

@section('content')
<div class="main-content">
    <div class="main-content-inner">
        @include('Elements.breadcrumb')
        @include('Elements.ace_setting')
        <div class="page-content">
            @include('Elements.all_form_css')
            <div class="page-header">
                <h1>
                    <?= $controller ?>
                    <small>
                        <i class="ace-icon fa fa-angle-double-right"></i>
                        Management
                    </small>
                </h1>
            </div><!-- /.page-header -->

            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->
                    @include('Elements.message')

                    <div id="jqgrid">

                        <table id="grid-table"></table>

                        <div id="grid-pager"></div>
                    </div>

                    <script type="text/javascript">
                        var $path_base = "/";
                    </script>

                    <div class="row">
                        <div class="space-6"></div>
                    </div>

                    <!-- PAGE CONTENT ENDS -->
                </div><!-- /.col -->
            </div><!-- /.row -->
            @include('Elements.all_form_js')

            <!-- inline scripts related to this page -->
            <script type="text/javascript">
                const grid_selector = "#grid-table";
                const pager_selector = "#grid-pager";

                jQuery(function ($) {

                    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': CSRF_TOKEN
                        }
                    });

                    var parent_column = $(grid_selector).closest('[class*="col-"]');
                    //resize to fit page size
                    $(window).on('resize.jqGrid', function () {
                        $(grid_selector).jqGrid('setGridWidth', parent_column.width());
                    })

                    //resize on sidebar collapse/expand
                    $(document).on('settings.ace.jqGrid', function (ev, event_name, collapsed) {
                        if (event_name === 'sidebar_collapsed' || event_name === 'main_container_fixed') {
                            //setTimeout is for webkit only to give time for DOM changes and then redraw!!!
                            setTimeout(function () {
                                $(grid_selector).jqGrid('setGridWidth', parent_column.width());
                            }, 20);
                        }
                    })

                    jQuery(grid_selector).jqGrid({
                        url: '<?php echo BASE_URL ?>admin/records',
                        height: '50%',
                        datatype: 'json',
                        colNames: ['', 'id', 'full_name', 'email', 'password', 'created_date', 'modified_date', 'status'],
                        colModel: [{
                                name: 'myac',
                                index: '',
                                width: 100,
                                fixed: true,
                                sortable: false,
                                resize: false,
                                formatter: 'actions',
                                formatoptions: {
                                    keys: true,

                                    delOptions: {
                                        recreateForm: true,
                                        beforeShowForm: beforeDeleteCallback
                                    },
                                }
                            },
                            {name: 'id', index: 'id', width: 55},
                            {name: 'full_name', index: 'full_name', width: 90},
                            {name: 'email', index: 'email', width: 80},
                            {name: 'password', index: 'password', width: 80},
                            {name: 'created_date', index: 'created_date', width: 80},
                            {name: 'modified_date', index: 'modified_date', width: 80},
                            {name: 'status', index: 'status', width: 80, editable: false, editoptions: {value: "1:2"}, formatter: checkboxFormatter, formatoptions: {disabled: false}, sortable: false},
                        ],

                        viewrecords: true,
                        rowNum: 10,
                        rowList: [10, 20, 30],
                        pager: pager_selector,
                        altRows: true,
                        //toppager: true,

                        multiselect: true,
                        //multikey: "ctrlKey",
                        multiboxonly: true,
                        editurl: "/admin/inline", //nothing is saved
                        caption: "<?php echo $controller; ?>",

                        //,autowidth: true,

                        loadComplete: function () {
                            var table = this;
                            setTimeout(function () {
                                styleCheckbox(table);

                                updateActionIcons(table);
                                updatePagerIcons(table);
                                enableTooltips(table);
                            }, 0);

                            var iCol_action = getColumnIndexByName($(this), 'myac');
                            $(this).children("tbody")
                                    .children("tr.jqgrow")
                                    .children("td:nth-child(" + (iCol_action + 1) + ")")
                                    .each(function () {
                                        $("<div>",
                                                {
                                                    title: "New tab link",
                                                    mouseover: function () {
                                                        $(this).addClass('ui-state-hover');
                                                    },
                                                    mouseout: function () {
                                                        $(this).removeClass('ui-state-hover');
                                                    },
                                                    click: function (e) {
                                                        //                                                window.open('admin/edit/' + $(e.target).closest("tr.jqgrow").attr("id"), "_blank");
                                                        window.location = '/admin/edit/' + $(e.target).closest("tr.jqgrow").attr("id");
                                                    }
                                                }
                                        ).css({"margin-left": "5px", float: "left"})
                                                .addClass("ui-pg-div ui-inline-custom")
                                                .append('<span class="ui-icon fa-external-link dark"></span>')
                                                .appendTo($(this).children("div"));
                                    });

                            var iCol = getColumnIndexByName($(this), 'status'), rows = this.rows, i, c = rows.length;

                            for (i = 0; i < c; i += 1) {
                                $(rows[i].cells[iCol]).click(function (e) {
                                    var id = $(e.target).closest('tr')[0].id, isChecked = $(e.target).is(':checked');
                                    var status_val = 2;
                                    //you can also get the values of the row data
                                    if (isChecked) {
                                        status_val = 1;
                                    }
                                    $.ajax({
                                        type: 'POST',
                                        url: '/admin/update_status',
                                        data: {
                                            'id': id, 'status_val': status_val,
                                        },
                                        success: function (msg) {
                                            //alert('done' + msg);
                                        }
                                    });
                                });
                            }
                        },

                    });
                });
            </script>

            @include('Elements.jqgrid.jqgrid_js')
        </div><!-- /.page-content -->

    </div>
</div><!-- /.main-content -->


@endsection('content')
