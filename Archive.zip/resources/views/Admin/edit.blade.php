@extends('Layout.default')

@section('content')

<?php 
?>

<div class="main-content">
    <div class="main-content-inner">
        @include('Elements.breadcrumb')
        @include('Elements.ace_setting')
        <div class="page-content">
            @include('Elements.all_form_css')
            <div class="page-header">
                <h1>
                    <?=$controller ?>
                    <small>
                        <i class="ace-icon fa fa-angle-double-right"></i>
                        Management
                    </small>
                </h1>
            </div><!-- /.page-header -->

            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->
                    <form action="/admin/update/{{ $datas->id }}" class="form-horizontal" role="form" enctype="multipart/form-data" id="adminAddForm" method="POST" accept-charset="utf-8">
                        @csrf
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right" for="full_name"> Full Name : </label>
                            <div class="col-sm-9">
                                <div class="clearfix">
                                    <input name="full_name" value="{{ $datas->full_name }}" type="text" id="full_name" class="col-xs-10 col-sm-5" placeholder="Enter Full Name" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right"  for="email"> Email : </label>
                            <div class="col-sm-9">
                                <div class="clearfix">
                                    <input name="email" value="{{ $datas->email }}" type="text" id="email" class="col-xs-10 col-sm-5" placeholder="Enter Email" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label no-padding-right"  for="password"> Password : </label>
                            <div class="col-sm-9">
                                <div class="clearfix">
                                    <input name="password" value="{{ $datas->password }}" type="text" id="password" class="col-xs-10 col-sm-5" placeholder="Enter Password" required="">
                                </div>

                            </div>
                        </div>

                        <div class="clearfix form-actions">
                            <div class="col-md-offset-3 col-md-9">
                                <button class="btn btn-info" id="add_submit" type="submit">
                                    <i class="ace-icon fa fa-check bigger-110"></i>
                                    Submit
                                </button>

                                &nbsp; &nbsp; &nbsp;
                                <button class="btn" type="reset">
                                    <i class="ace-icon fa fa-undo bigger-110"></i>
                                    Reset
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="row">
                        <div class="space-6"></div>
                    </div>                    
                    <!-- PAGE CONTENT ENDS -->
                </div><!-- /.col -->
            </div><!-- /.row -->
            @include('Elements.all_form_js')

            <!-- inline scripts related to this page -->
            <script type="text/javascript" language="javascript" class="init">

                jQuery(function ($) {

                    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': CSRF_TOKEN
                        }
                    });

                    $.validator.setDefaults({
                        ignore: [],
                        // any other default options and/or rules
                    });

                    $('#adminAddForm').validate({
                        errorElement: 'div',
                        errorClass: 'help-block',
                        focusInvalid: false,
                        rules: {
                        },

                        highlight: function (e) {
                            $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
                        },

                        success: function (e) {
                            $(e).closest('.form-group').removeClass('has-error').addClass('has-info');
                            $(e).remove();
                        },

                        errorPlacement: function (error, element) {
                            if (element.is(':checkbox') || element.is(':radio')) {
                                var controls = element.closest('div[class*="col-"]');
                                if (controls.find(':checkbox,:radio').length > 1)
                                    controls.append(error);
                                else
                                    error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                            } else if (element.is('.select2')) {
                                error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                            } else if (element.is('.chosen-select')) {
                                error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                            } else
                                error.insertAfter(element.parent());
                        }
                    });
                });

                $(document).ready(function () {
                    $("#add_submit").click(function () {
                        if ($("#adminAddForm").valid() === true) {
                            $("#adminAddForm").submit();
                        }
                        return false;
                    });
                });
            </script>
        </div><!-- /.page-content -->

    </div>

</div><!-- /.main-content -->

@endsection('content')