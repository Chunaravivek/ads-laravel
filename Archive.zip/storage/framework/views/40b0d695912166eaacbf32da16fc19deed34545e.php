<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <span class="bigger-120">
                <span class="blue bolder">Ace</span>
                Application © 2013-2022
            </span>
        </div>
    </div>
</div>

</div><!-- /.main-container -->
<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
    <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>

<!-- <![endif]-->

<!--[if IE]>
<script src="<?php echo BASE_URL ?>assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
<script type="text/javascript">
    if ('ontouchstart' in document.documentElement)
        document.write("<script src='<?php echo BASE_URL ?>assets/js/jquery.mobile.custom.min.js'>" + "<" + "/script>");
</script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap.min.js"></script>

<!-- page specific plugin scripts -->

<!--[if lte IE 8]>
  <script src="<?php echo BASE_URL ?>assets/js/excanvas.min.js"></script>
<![endif]-->
<script src="<?php echo BASE_URL ?>assets/js/jquery-ui.custom.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.ui.touch-punch.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.easypiechart.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.sparkline.index.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.flot.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.flot.pie.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.flot.resize.min.js"></script>

<!-- ace scripts -->
<script src="<?php echo BASE_URL ?>assets/js/ace-elements.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/ace.min.js"></script>

<!-- inline scripts related to this page -->
<script type="text/javascript">
    jQuery(function ($) {
    })
</script>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
            (function (d, w, c) {
                (w[c] = w[c] || []).push(function () {
                    try {
                        w.yaCounter25836836 = new Ya.Metrika({id: 25836836,
                            webvisor: true,
                            clickmap: true,
                            trackLinks: true,
                            accurateTrackBounce: true});
                    } catch (e) {
                    }
                });

                var n = d.getElementsByTagName("script")[0],
                        s = d.createElement("script"),
                        f = function () {
                            n.parentNode.insertBefore(s, n);
                        };
                s.type = "text/javascript";
                s.async = true;
                s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

                if (w.opera == "[object Opera]") {
                    d.addEventListener("DOMContentLoaded", f, false);
                } else {
                    f();
                }
            })(document, window, "yandex_metrika_callbacks");
</script>
<noscript>
<div>
    <img src="//mc.yandex.ru/watch/25836836" style="position:absolute; left:-9999px;" alt="" />
</div>
</noscript>
<!-- /Yandex.Metrika counter -->
<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-38894584-2', 'auto');
    ga('send', 'pageview');

</script>

</body>
</html><?php /**PATH /Library/WebServer/Documents/ads_laravel/resources/views/Elements/footer.blade.php ENDPATH**/ ?>