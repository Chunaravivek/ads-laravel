<!-- inline scripts related to this page -->
<script type="text/javascript">
    jQuery(function ($) {

        $(window).triggerHandler('resize.jqGrid'); //trigger window resize to make the grid get the correct size


        //enable search/filter toolbar
        //jQuery(grid_selector).jqGrid('filterToolbar',{defaultSearch:true,stringResult:true})
        //jQuery(grid_selector).filterToolbar({});


        //navButtons
        jQuery(grid_selector).jqGrid('navGrid', pager_selector, {//navbar options
            edit: false,
            editicon: 'ace-icon fa fa-pencil blue',
            add: false,
            addicon: 'ace-icon fa fa-plus-circle purple',
            del: true,
            delicon: 'ace-icon fa fa-trash-o red',
            search: true,
            searchicon: 'ace-icon fa fa-search orange',
            refresh: true,
            refreshicon: 'ace-icon fa fa-refresh green',
            view: true,
            viewicon: 'ace-icon fa fa-search-plus grey',
        }, {
            //edit record form
            //closeAfterEdit: true,
            //width: 700,
            recreateForm: true,
            beforeShowForm: function (e) {
                var form = $(e[0]);
                form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
                style_edit_form(form);
            }
        }, {
            //new record form
            //width: 700,
            closeAfterAdd: true,
            recreateForm: true,
            viewPagerButtons: false,
            beforeShowForm: function (e) {
                var form = $(e[0]);
                form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar')
                        .wrapInner('<div class="widget-header" />')
                style_edit_form(form);
            }
        }, {
            //delete record form
            recreateForm: true,
            beforeShowForm: function (e) {
                var form = $(e[0]);
                if (form.data('styled'))
                    return false;

                form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
                style_delete_form(form);

                form.data('styled', true);
            },
            onClick: function (e) {
                //alert(1);
            }
        }, {
            //search form
            recreateForm: true,
            afterShowSearch: function (e) {
                var form = $(e[0]);
                form.closest('.ui-jqdialog').find('.ui-jqdialog-title').wrap('<div class="widget-header" />')
                style_search_form(form);
            },
            afterRedraw: function () {
                style_search_filters($(this));
            },
            multipleSearch: true,
            
        }, {
            //view record form
            recreateForm: true,
            beforeShowForm: function (e) {
                var form = $(e[0]);
                form.closest('.ui-jqdialog').find('.ui-jqdialog-title').wrap('<div class="widget-header" />')
            }
        }).navButtonAdd(pager_selector, {
            // custom add button
            caption: "",
            buttonicon: "ace-icon fa fa-pencil blue",
            onClickButton: function () {
                var grid = $("#grid-table"); // ur jqgrid "#grid-table"
                //console.log(grid);
                var rowid = grid.jqGrid('getGridParam', 'selrow'); // get the selected rowid
                //console.log(rowid);
                //console.log(isNaN(rowid));
                // u can get the cell value of the row by
                // grid.jqGrid('getCell', rowid, 'rowName');

                if (rowid != '' && rowid != null && isNaN(rowid) == false) {
                    window.location = '<?php echo $controller; ?>/edit/' + rowid;

                }
            },
            position: "first"
        }).navButtonAdd(pager_selector, {
            // custom add button
            caption: "",
            buttonicon: "ace-icon fa fa-plus-circle purple",
            onClickButton: function () {
                var grid = $("#grid-table"); // ur jqgrid "#grid-table"
                var rowid = grid.jqGrid('getGridParam', 'selrow'); // get the selected rowid
                if (1 == 1) {
                    window.location = '<?php echo BASE_URL ?><?php echo $controller; ?>/create';
                }
            },
            position: "first"
        })

        //var selr = jQuery(grid_selector).jqGrid('getGridParam','selrow');

        $(document).one('ajaxloadstart.page', function (e) {
            $.jgrid.gridDestroy(grid_selector);
            $('.ui-jqdialog').remove();
        });
    });
</script>

<?php echo $__env->make('Elements.jqgrid.function', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Library/WebServer/Documents/ads_laravel/resources/views/Elements/jqgrid/jqgrid_js.blade.php ENDPATH**/ ?>