<script type="text/javascript">
    //switch element when editing inline
    function aceSwitch(cellvalue, options, cell) {
        setTimeout(function () {
            $(cell).find('input[type=checkbox]')
                    .addClass('ace ace-switch ace-switch-5')
                    .after('<span class="lbl"></span>');
        }, 0);
    }
    //enable datepicker
    function pickDate(cellvalue, options, cell) {
        setTimeout(function () {
            $(cell).find('input[type=text]')
                    .datepicker({
                        format: 'yyyy-mm-dd',
                        autoclose: true
                    });
        }, 0);
    }

    function style_edit_form(form) {
        //enable datepicker on "sdate" field and switches for "stock" field
        form.find('input[name=sdate]').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        })

        form.find('input[name=stock]').addClass('ace ace-switch ace-switch-5').after('<span class="lbl"></span>');
        //don't wrap inside a label element, the checkbox value won't be submitted (POST'ed)
        //.addClass('ace ace-switch ace-switch-5').wrap('<label class="inline" />').after('<span class="lbl"></span>');


        //update buttons classes
        var buttons = form.next().find('.EditButton .fm-button');
        buttons.addClass('btn btn-sm').find('[class*="-icon"]').hide(); //ui-icon, s-icon
        buttons.eq(0).addClass('btn-primary').prepend('<i class="ace-icon fa fa-check"></i>');
        buttons.eq(1).prepend('<i class="ace-icon fa fa-times"></i>')

        buttons = form.next().find('.navButton a');
        buttons.find('.ui-icon').hide();
        buttons.eq(0).append('<i class="ace-icon fa fa-chevron-left"></i>');
        buttons.eq(1).append('<i class="ace-icon fa fa-chevron-right"></i>');
    }

    function style_delete_form(form) {
        var buttons = form.next().find('.EditButton .fm-button');
        buttons.addClass('btn btn-sm btn-white btn-round').find('[class*="-icon"]').hide(); //ui-icon, s-icon
        buttons.eq(0).addClass('btn-danger').prepend('<i class="ace-icon fa fa-trash-o"></i>');
        buttons.eq(1).addClass('btn-default').prepend('<i class="ace-icon fa fa-times"></i>')
    }

    function style_search_filters(form) {
        form.find('.delete-rule').val('X');
        form.find('.add-rule').addClass('btn btn-xs btn-primary');
        form.find('.add-group').addClass('btn btn-xs btn-success');
        form.find('.delete-group').addClass('btn btn-xs btn-danger');
    }

    function style_search_form(form) {
        var dialog = form.closest('.ui-jqdialog');
        var buttons = dialog.find('.EditTable')
        buttons.find('.EditButton a[id*="_reset"]').addClass('btn btn-sm btn-info').find('.ui-icon').attr('class', 'ace-icon fa fa-retweet');
        buttons.find('.EditButton a[id*="_query"]').addClass('btn btn-sm btn-inverse').find('.ui-icon').attr('class', 'ace-icon fa fa-comment-o');
        buttons.find('.EditButton a[id*="_search"]').addClass('btn btn-sm btn-purple').find('.ui-icon').attr('class', 'ace-icon fa fa-search');
    }

    function beforeDeleteCallback(e) {
        var form = $(e[0]);
        if (form.data('styled'))
            return false;

        form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
        style_delete_form(form);

        form.data('styled', true);
    }

    function beforeEditCallback(e) {
        var form = $(e[0]);
        form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
        style_edit_form(form);
    }

    //it causes some flicker when reloading or navigating grid
    //it may be possible to have some custom formatter to do this as the grid is being created to prevent this
    //or go back to default browser checkbox styles for the grid
    function styleCheckbox(table) {
        
    }


    //unlike navButtons icons, action icons in rows seem to be hard-coded
    //you can change them like this in here if you want
    function updateActionIcons(table) {
        
    }

    //replace icons with FontAwesome icons like above
    function updatePagerIcons(table) {
        var replacement = {
            'ui-icon-seek-first': 'ace-icon fa fa-angle-double-left bigger-140',
            'ui-icon-seek-prev': 'ace-icon fa fa-angle-left bigger-140',
            'ui-icon-seek-next': 'ace-icon fa fa-angle-right bigger-140',
            'ui-icon-seek-end': 'ace-icon fa fa-angle-double-right bigger-140'
        };
        $('.ui-pg-table:not(.navtable) > tbody > tr > .ui-pg-button > .ui-icon').each(function () {
            var icon = $(this);
            var $class = $.trim(icon.attr('class').replace('ui-icon', ''));

            if ($class in replacement)
                icon.attr('class', 'ui-icon ' + replacement[$class]);
        })
    }

    function enableTooltips(table) {
        $('.navtable .ui-pg-button').tooltip({
            container: 'body'
        });
        $(table).find('.ui-pg-div').tooltip({
            container: 'body'
        });
    }

    function checkboxFormatter(cellvalue, options, rowObject, rowid) {
        var checked = '';
        if (cellvalue == '1')
        {
            checked = "checked='checked'";
        }
        return "<label style='margin:0 0 0 0px'>\
                <input type='checkbox' " + checked + " class='ace ace-switch ace-switch-3' value='" + cellvalue + "'><span class='lbl'></span></label>";
    }

    var getColumnIndexByName = function (grid, columnName) {
        var cm = grid.jqGrid('getGridParam', 'colModel'), i, l = cm.length;
        for (i = 0; i < l; i++) {
            //alert(cm[i].name);
            if (cm[i].name === columnName) {
                return i; // return the index
            }
        }
        return -1;
    }

    function GetTypeCities(cellvalue, options, rowObject, rowid) {
//                            var checked = '';
        if (cellvalue == '1')
        {
            return "<label style='margin:0 0 0 30px'>City</label>";
        } else if (cellvalue == '2') {
            return "<label style='margin:0 0 0 30px'>State</label>";
        } else {
            return "<label style='margin:0 0 0 30px'>Country</label>";
        }

    }

    function apps_urls(cellvalue, options, rowObject, rowid) {
        var acc_url = rowObject[5];
        var live_plays = rowObject[6];

        if (acc_url && live_plays == 2)
        {
            return "<label style='margin:0 0 0 0px'><a href=https://play.google.com/store/apps/details?id=" + acc_url + " target='_blank'>" + cellvalue + "</a></label>";
        } else {
            return "<label style='margin:0 0 0 0px'>" + cellvalue + "</label>";
        }
    }
    function accountUrls_test(cellvalue, options, rowObject, rowid) {
        var acc_url = rowObject[3];
        var live_plays = rowObject[12];

        if (acc_url && live_plays == 2)
        {
            return "<label style='margin:0 0 0 0px'><a href=https://play.google.com/store/apps/details?id=" + acc_url + " target='_blank'>" + cellvalue + "</a></label>";
        } else {
            return cellvalue;
        }
    }

    function accountUrls(cellvalue, options, rowObject, rowid) {
        var live_play = rowObject[12];

        if (cellvalue && live_play == 2)
        {
            return "<label style='margin:0 0 0 0px'><a href=" + cellvalue + " target='_blank' >" + cellvalue + "</a></label>";
        } else if (cellvalue && live_play == 3) {
            return "<label style='margin:0 0 0 0px'>" + cellvalue + "</label>";
        } else {
            return "<label style='margin:0 0 0 0'><a href=" + cellvalue + " target='_blank' >" + cellvalue + "</a></label>";
        }
    }

    function PlayStoreStatus(cellvalue, options, rowObject, rowid) {
        if (cellvalue == '1')
        {
            return "<label style='margin:0 0 0 30px; color:orange;'>Pending</label>";
        } else if (cellvalue == '2') {
            return "<label style='margin:0 0 0 30px' class='text-success'>Live</label>";
        } else if (cellvalue == '3') {
            return "<label style='margin:0 0 0 30px;' class='text-danger'>suspended</label>";
        } else {
            return "<label style='margin:0 0 0 30px'>-</label>";
        }
    }

    function UpdateForStatus(cellvalue, options, rowObject, rowid) {
        if (cellvalue == '2')
        {
            return "<label style='margin:0 0 0 0'>Updated</label>";
        } else {
            return "<label style='margin:0 0 0 0'>Not Updated</label>";
        }

    }

    function returnurls(cellvalue, options, rowObject, rowid) {
        if (cellvalue)
        {
            return "<label style='margin:0 0 0 0px'><a href='http://api2.s4apps.in/cron/Ads_id/" + cellvalue + "_ad_id.json' target='_blank'>" + cellvalue + "</a></label>";
        } else {
            return "<label style='margin:0 0 0 0px'>-</label>";
        }
    }
</script>
<?php /**PATH /Library/WebServer/Documents/ads_laravel/resources/views/Elements/jqgrid/function.blade.php ENDPATH**/ ?>