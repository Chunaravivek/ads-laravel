<div class="breadcrumbs ace-save-state" id="breadcrumbs">
    <ul class="breadcrumb">
        <li>
            <i class="ace-icon fa fa-home home-icon"></i>
            <a href="<?php echo BASE_URL; ?>dashboard">Home</a>
        </li>
        <?php
        if ($action == 'create' || $action == 'edit') {
            ?>
            <li>
                <a href="<?php echo BASE_URL; ?><?php echo $controller; ?>"><?php echo $controller; ?></a>
            </li>
            <li class="active"><?php echo $action; ?></li>
        <?php } else { ?>
            <li class="active"><?php echo $controller; ?></li>
        <?php } ?>
    </ul><!-- /.breadcrumb -->
</div><?php /**PATH /Library/WebServer/Documents/ads_laravel/resources/views/Elements/breadcrumb.blade.php ENDPATH**/ ?>