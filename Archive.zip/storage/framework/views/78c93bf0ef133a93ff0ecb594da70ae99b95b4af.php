<!-- page specific plugin scripts -->
<script src="<?php echo BASE_URL ?>assets/js/jquery-ui.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery-ui.custom.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.ui.touch-punch.min.js"></script>
<script type='text/javascript' src='<?php echo BASE_URL ?>assets/js/grid.locale-en.js'></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.jqGrid.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.validate.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery-additional-methods.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/chosen.jquery.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/moment.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.ui.touch-punch.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.knob.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.inputlimiter.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.maskedinput.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap-tag.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/markdown.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap-markdown.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.hotkeys.index.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootstrap-wysiwyg.min.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/bootbox.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.gritter.js"></script>
<script src="<?php echo BASE_URL ?>assets/js/jquery.gritter.min.js"></script>
<?php /**PATH /Library/WebServer/Documents/ads_laravel/resources/views/Elements/all_form_js.blade.php ENDPATH**/ ?>